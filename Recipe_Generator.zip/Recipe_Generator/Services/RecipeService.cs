using Microsoft.EntityFrameworkCore;
using Recipe_Generator.Pages;

namespace Recipe_Generator.Services
{
    public class RecipeService
    {
        private readonly RecipeDbContext _context;

        public RecipeService(RecipeDbContext context)
        {
            _context = context;
        }

        public async Task<List<Recipe>> GetRecipesAsync()
        {
            try
            {
                return await _context.Recipes.ToListAsync();
            }
            catch (Exception ex)
            {
                // Log the error
                Console.Error.WriteLine($"Error in GetRecipesAsync: {ex.Message}");
                // Consider throwing a more specific exception or re-throwing the original
                throw;
            }
        }

        public async Task<Recipe> GetRecipeAsync(int id)
        {
            try
            {
                Recipe? foundRecipe = await _context.Recipes.FindAsync(id);
                return GetFoundRecipe(foundRecipe);
            }
            catch (Exception ex)
            {
                // Log the error
                Console.Error.WriteLine($"Error in GetRecipeAsync: {ex.Message}");
                throw;
            }
        }

        static Recipe GetFoundRecipe(Recipe? foundRecipe) => foundRecipe;

        public async Task AddRecipeAsync(Recipe recipe)
        {
            try
            {
                _context.Recipes.Add(recipe);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                // Handle database-related errors (e.g., connection issues, constraint violations)
                Console.Error.WriteLine($"Error adding recipe: {ex.Message}");
                throw; // Re-throw the exception
            }
            catch (Exception ex)
            {
                // Handle other exceptions
                Console.Error.WriteLine($"Error adding recipe: {ex.Message}");
                throw;
            }
        }

        public async Task UpdateRecipeAsync(Recipe recipe)
        {
            try
            {
                _context.Recipes.Update(recipe);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                Console.Error.WriteLine($"Error updating recipe: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error updating recipe: {ex.Message}");
                throw;
            }
        }

        public async Task DeleteRecipeAsync(int id)
        {
            try
            {
                var recipe = await _context.Recipes.FindAsync(id);
                if (recipe != null)
                {
                    _context.Recipes.Remove(recipe);
                    await _context.SaveChangesAsync();
                }
            }
            catch (DbUpdateException ex)
            {
                Console.Error.WriteLine($"Error deleting recipe: {ex.Message}");
                throw;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error deleting recipe: {ex.Message}");
                throw;
            }
        }

        public async Task<List<string>> GetCategoriesAsync()
        {
            try
            {
                return await _context.Recipes
                    .Select(static r =>
                    {
                        return r.Category;
                    })
                    .Distinct()
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"Error getting categories: {ex.Message}");
                throw;
            }
        }
    }
}

