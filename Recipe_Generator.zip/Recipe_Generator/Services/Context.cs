﻿namespace Recipe_Generator.Services
{
    public class Context
    {

        public RecipeDbContext GetContext()
        {
            return _context;
        }
    }
}