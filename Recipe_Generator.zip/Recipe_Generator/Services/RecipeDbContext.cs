﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging; // Add this

namespace Recipe_Generator.Services
{
    public class RecipeService
    {
        private readonly RecipeDbContext _context;
        private readonly ILogger<RecipeService> _logger; // Add this

        public RecipeService(RecipeDbContext context, ILogger<RecipeService> logger) // Update constructor
        {
            _context = context;
            _logger = logger;
        }

        public async Task<List<Recipe>> GetRecipesAsync()
        {
            try
            {
                return await _context.Recipes.ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(GetRecipesAsync));
                throw;
            }
        }

        public async Task<Recipe?> GetRecipeAsync(int id)
        {
            try
            {
                var recipe = await _context.Recipes.FindAsync(id);
                if (recipe == null)
                {
                    _logger.LogWarning("Recipe with id {Id} not found", id);
                    return null; // Or throw an exception if you prefer
                }
                return recipe;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(GetRecipeAsync));
                throw;
            }
        }


        public async Task AddRecipeAsync(Recipe recipe)
        {
            try
            {
                _context.Recipes.Add(recipe);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(AddRecipeAsync));
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(AddRecipeAsync));
                throw;
            }
        }

        public async Task UpdateRecipeAsync(Recipe recipe)
        {
            try
            {
                _context.Recipes.Update(recipe);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(UpdateRecipeAsync));
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(UpdateRecipeAsync));
                throw;
            }
        }

        public async Task DeleteRecipeAsync(int id)
        {
            try
            {
                var recipe = await _context.Recipes.FindAsync(id);
                if (recipe != null)
                {
                    _context.Recipes.Remove(recipe);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    _logger.LogWarning("Recipe with id {Id} not found", id);
                    throw new KeyNotFoundException($"Recipe with id {id} not found.");
                }
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(DeleteRecipeAsync));
                throw;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(DeleteRecipeAsync));
                throw;
            }
        }

        public async Task<List<string>> GetCategoriesAsync()
        {
            try
            {
                return await _context.Recipes
                    .Select(r => r.Category)
                    .Distinct()
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in {MethodName}", nameof(GetCategoriesAsync));
                throw;
            }
        }
    }
}

}